
export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen">

      <section className="text-center py-24 px-6">
        <h1 className="text-5xl font-bold">BMC MILLY</h1>
        <p className="mt-4 text-gray-400 uppercase tracking-widest">
          Underrated but never overlooked.
        </p>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-semibold mb-10 text-center">Latest Releases</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <img src="/images/underrated-cover.jpg" className="rounded-xl" />
            <p className="mt-4">Underrated</p>
          </div>
          <div>
            <img src="/images/takeover-cover.jpg" className="rounded-xl" />
            <p className="mt-4">Takeover</p>
          </div>
          <div>
            <iframe
              className="rounded-xl"
              src="https://open.spotify.com/embed/album/5Nm6sNkUsV5Uk362CGJYJw"
              width="100%"
              height="380"
              allow="encrypted-media"
            />
            <p className="mt-4">Tricking Xmas</p>
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-20 text-center">
        <h2 className="text-3xl font-semibold mb-8">Watch the Official Video</h2>
        <div className="relative pb-[56.25%]">
          <iframe
            className="absolute top-0 left-0 w-full h-full rounded-xl"
            src="https://www.youtube.com/embed/OGIC6dTcFKw"
            allowFullScreen
          />
        </div>
      </section>

      <section className="py-24 text-center bg-zinc-950">
        <img src="/images/mente-millionaria-logo.jpg" className="mx-auto max-w-md" />
        <p className="mt-6 text-gray-400">
          Luxury street culture. First drop coming soon.
        </p>
      </section>

      <footer className="py-6 text-center text-gray-500 border-t border-zinc-800">
        © {new Date().getFullYear()} BMC Milly
      </footer>

    </main>
  );
}
